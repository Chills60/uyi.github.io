/*

***Simple Registration Form Program***
@version 1.0
@author Uyi Emeka Ihegie ucihegie@gmail.com

This exercise program is to collect user data and display it back. Data
collected for display will be user first name, last name, address details and age. 

*/
package uyi.nameaddress;
import java.util.*; // this imports all the classes and interfaces within java. utility package.
// here we will use Scanner which is located in utility package.

public class NameAddress {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in); // Create an instance of a scanner object

        //collect client input and store in variable. Each request for client information is first printed in the previous line as strings.

        System.out.println("Enter your last name:"); //display prompt for user to input last name
        String lastName = scan.nextLine(); //reads the entire line input from user, then position the cursor in the next line.

        System.out.println("Enter your first name:");
        String firstName = scan.nextLine();

        System.out.println("Enter your middle name:");
        String middleName = scan.nextLine();

        System.out.println("Enter your house number:");
        String huNumber = scan.nextLine();

        System.out.println("Enter your street name:");
        String streetName = scan.nextLine();

        System.out.println("Enter your street type:");
        String streetType = scan.nextLine();

        System.out.println("Enter your city:");
        String city = scan.nextLine();

        System.out.println("Enter your age:");
        int age = scan.nextInt();

        //capitalise the first letter(substring 0,1) input for firstname, middlename, lastname and steet details & city input then store in same variable.
        firstName = firstName.substring(0, 1).toUpperCase() + firstName.substring(1);
        middleName = middleName.substring(0, 1).toUpperCase() + middleName.substring(1);
        lastName = lastName.substring(0, 1).toUpperCase() + lastName.substring(1);
        streetName = streetName.substring(0, 1).toUpperCase() + streetName.substring(1);
        streetType = streetType.substring(0, 1).toUpperCase() + streetType.substring(1);
        city = city.substring(0, 1).toUpperCase() + city.substring(1);

        //display a new line        
        //display only first character of firstname and middle name followed by fullstop "." for each. Then display lastname. 
        //display in next line, house or unit number, street name and then street type. 
        //display city on next line.   

        System.out.println("\n");
        System.out.println(firstName.charAt(0) + "." + middleName.charAt(0) + ". " + lastName);
        System.out.println(huNumber + " " + streetName + " " + streetType);
        System.out.println(city);
        // check the number range that age integer is under. Display the age bracket string according to the number range.        
        if (age <= 20) {
            System.out.println("Age Bracket: 20 or under");
        } else if (age >= 21 && age <= 35) {
            System.out.println("Age Bracket: 21-35");
        } else if (age >= 36 && age <= 70) {
            System.out.println("Age Bracket: 36-70");
        } else if (age >= 71) {
            System.out.println("Age Bracket: 71 or over");
        }
    }
}